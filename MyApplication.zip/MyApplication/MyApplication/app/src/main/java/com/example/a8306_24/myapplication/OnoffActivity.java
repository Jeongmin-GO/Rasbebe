package com.example.a8306_24.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class OnoffActivity extends AppCompatActivity {
    private static final String TAG = "OnoffActivity";

    FirebaseDatabase database;
    DatabaseReference rasRef;

    Switch switch_a;
    Switch switch_b;
    Button btnquit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onoff);

        switch_a = (Switch)findViewById(R.id.switch1);
        switch_b = (Switch)findViewById(R.id.switch2);
        btnquit = (Button)findViewById(R.id.btnquit);

        database = FirebaseDatabase.getInstance();
        rasRef = database.getReference("multitap");

        //돌아가기 버튼 누르면 메인액티비티 이동
        btnquit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        //
        rasRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean result_A = dataSnapshot.child("switch_A").getValue(Boolean.class);
                Boolean result_B = dataSnapshot.child("switch_B").getValue(Boolean.class);
                switch_a.setChecked(result_A);
                switch_b.setChecked(result_B);
                Log.d(TAG, "Value is: " + result_A);
                Log.d(TAG, "Value is: " + result_B);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value.", databaseError.toException());
            }
        });

        switch_a.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    rasRef.child("switch_A").setValue(true);
                }else{
                    rasRef.child("switch_A").setValue(false);
                }
            }
        });

        switch_b.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    rasRef.child("switch_B").setValue(true);
                }else{
                    rasRef.child("switch_B").setValue(false);
                }
            }
        });
    }
}
