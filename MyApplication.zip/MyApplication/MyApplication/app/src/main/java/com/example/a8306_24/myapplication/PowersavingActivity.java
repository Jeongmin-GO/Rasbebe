package com.example.a8306_24.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PowersavingActivity extends AppCompatActivity {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference("powersaving");

    Button btnquit;
    ToggleButton timer10, timer30, timer1hour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_powersaving);

        btnquit = (Button)findViewById(R.id.quit);
        timer10 = (ToggleButton)findViewById(R.id.ten);
        timer30 = (ToggleButton)findViewById(R.id.toggleButton);
        timer1hour = (ToggleButton)findViewById(R.id.hour);

        //돌아가기 버튼 누르면 메인액티비티로 이동
        btnquit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        //(타이머10) 토글버튼 check되면 파이어베이스 Real-database값도 true, 아니면 false값으로 바뀜
        timer10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true){
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 10분 ON", Toast.LENGTH_SHORT).show();
                    ref.child("timer10").setValue(true);
                    ref.child("timer30").setValue(false);
                    ref.child("timer1hour").setValue(false);
                    timer1hour.setChecked(false);
                    timer30.setChecked(false);
                }else{
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 OFF", Toast.LENGTH_SHORT).show();
                    ref.child("timer10").setValue(false);
                }
            }
        });
        //(타이머30) 토글버튼 check되면 파이어베이스 Real-database값도 true, 아니면 false값으로 바뀜
        timer30.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true){
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 30분 ON", Toast.LENGTH_SHORT).show();
                    ref.child("timer30").setValue(true);
                    ref.child("timer10").setValue(false);
                    ref.child("timer1hour").setValue(false);
                    timer1hour.setChecked(false);
                    timer10.setChecked(false);
                }else{
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 OFF", Toast.LENGTH_SHORT).show();
                    ref.child("timer30").setValue(false);
                }
            }
        });
        //(타이머1시간) 토글버튼 check되면 파이어베이스 Real-database값도 true, 아니면 false값으로 바뀜
        timer1hour.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked == true){
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 1시간이 설정되었습니다.", Toast.LENGTH_SHORT).show();
                    ref.child("timer1hour").setValue(true);
                    ref.child("timer10").setValue(false);
                    ref.child("timer30").setValue(false);
                    timer30.setChecked(false);
                    timer10.setChecked(false);
                }else{
                    Toast.makeText(getApplicationContext(), "스마트 절전모드 OFF", Toast.LENGTH_SHORT).show();
                    ref.child("timer1hour").setValue(false);
                }
            }
        });

    }
}
